
from langchain.document_loaders import JSONLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain.embeddings import OpenAIEmbeddings

# Load documents
loader = JSONLoader(
    file_path="langchain_data\documents.json",
    jq_schema=".[]",
    content_key="page_content",
    metadata_func=lambda record, metadata: record.get("metadata", {})
)

documents = loader.load()
print(f"Loaded {len(documents)} documents")

# Optional: Further split if needed
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=1000,
    chunk_overlap=200
)
texts = text_splitter.split_documents(documents)

# Create vector store
embeddings = OpenAIEmbeddings()
vectorstore = Chroma.from_documents(
    documents=texts,
    embedding=embeddings,
    persist_directory="./chroma_db"
)

# Example: Search similar documents
query = "your search query here"
results = vectorstore.similarity_search(query, k=5)
for result in results:
    print(f"Source: {result.metadata['source']}")
    print(f"Section: {result.metadata['section']}")
    print(f"Content: {result.page_content[:200]}...")
    print("-" * 50)
